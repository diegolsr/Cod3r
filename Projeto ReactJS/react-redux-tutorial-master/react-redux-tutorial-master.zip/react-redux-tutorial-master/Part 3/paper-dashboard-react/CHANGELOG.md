## [1.0.0] 2018-10-12
### Original Release
- Added Reactstrap as base framework
- Added design from Paper Dashboard 2 by Creative Tim
