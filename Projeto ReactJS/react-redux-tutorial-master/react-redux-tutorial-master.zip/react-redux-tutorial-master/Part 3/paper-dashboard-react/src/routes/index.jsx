import Dashboard from "layouts/Dashboard/Dashboard.jsx";

var indexRoutes = [{ path: "/", name: "Home", component: Dashboard }];

export default indexRoutes;
